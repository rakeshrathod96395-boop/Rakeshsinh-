ઉમંગ Education — પ્રથમ પ્રોટોટાઇપ

- app/src/main/assets/index.html: ઇન્ટરેક્ટિવ ગુજરાતી મોબાઇલ પ્રોટોટાઇપ
- Android Studio project: WebView આધારિત Android એપનો સોર્સ કોડ

ઝડપી પૂર્વદર્શન: index.html ને Android/કમ્પ્યુટરના Chromeમાં ખોલો.
APK બનાવવા: Android Studioમાં આ પ્રોજેક્ટ Open કરો, Gradle Sync કરો, પછી Build > Build Bundle(s) / APK(s) > Build APK(s) પસંદ કરો.

નોંધ: આ UI પ્રોટોટાઇપ છે; APK અહીં કમ્પાઇલ કરાયેલ નથી. પુસ્તકો, વીડિયો, લાઇવ પરિણામો અને સ્કોલરશિપ ડેટાબેઝ હજી જોડાયેલા નથી.
